//
//  MainViewController.m
//  AuthTogether
//
//  Created by Nuseir Yassin on 11/1/14.
//  Copyright (c) 2014 Nuseir Yassin. All rights reserved.
//

#import "MainViewController.h"
#import "ViewController.h"
#import "HTTPClient.h"
#import "NewReportViewController.h"
#import "TableCellTableViewCell.h"
#import "AFNetworking.h"
#import "DetailViewController.h"

static NSString * const BaseURLString = @"http://jhans.ch:3000/";


@interface MainViewController ()

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    [self.startButton setBackgroundColor:[UIColor redColor]];
    UIBarButtonItem *logOutButton = [[UIBarButtonItem alloc] initWithTitle:@"Log Out" style:UIBarButtonItemStylePlain
                                                target:self
                                                action:@selector(logUserOut)];
    
    self.navigationItem.leftBarButtonItem = logOutButton;

    
    
    NSString *savedValue = [[NSUserDefaults standardUserDefaults]
                            stringForKey:@"phoneNumber"];
    
    if (savedValue) {
        NSLog(@"ALREADY AVAILABLE");
        
//        [[HTTPClient sharedInstance] getTransactionsForID:savedValue forController:self];
        
        [self fetchData];
        
    } else {
        NSLog(@"Can't Find anything");
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        ViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"SignUpVC"];
        [self presentViewController:vc animated:NO completion:nil];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableViewDelegates

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;    //count of section
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [self.list count];    //count number of row from counting array hear cataGorry is An Array
}



- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *MyIdentifier = @"reportCell";
    
    
    
    TableCellTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier];
    
    if (cell == nil)
    {
        cell = [[TableCellTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                       reuseIdentifier:MyIdentifier];
    }
    
    NSDictionary *transaction =  [self.list objectAtIndex:indexPath.row];
    
    cell.labelAmount.text = [[transaction objectForKey:@"amount"] stringValue];
    NSString *stringFromDate = [transaction objectForKey:@"createdAt"];
    cell.labelDate.text = stringFromDate;
    cell.labelHeader.text = [transaction objectForKey:@"description"] ;
    cell.labelStatus.text = [transaction objectForKey:@"status"];
    return cell;
}

#pragma mark - Navigation


- (void)addButtonPressed
{

    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    NewReportViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"newReport"];
    [self presentViewController:vc animated:NO completion:nil];
}

- (void)logUserOut
{
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"phoneNumber"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"SignUpVC"];
    [self presentViewController:vc animated:NO completion:nil];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([segue.identifier isEqualToString:@"description"]) {

        NSIndexPath *indexPath = [self.tableView indexPathForCell:sender];
        DetailViewController *destination = segue.destinationViewController;
        destination.item = [self.list objectAtIndex:indexPath.row];

    }
    
}

- (void)fetchData {
    
    NSString * phoneNumber = @"4083685136";
    
    NSString *completedString = [NSString stringWithFormat:@"api/user/%@/submission", phoneNumber];
    
    NSString *string = [BaseURLString stringByAppendingString:completedString];
    
    NSURL *url = [NSURL URLWithString:string];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    // 2
    
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    operation.responseSerializer = [AFJSONResponseSerializer serializer];
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        // 3
        NSArray *response = (NSArray *)responseObject;
        
        self.list = response;
        [self.tableView reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        // 4
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error Retrieving Data"
                                                            message:[error localizedDescription]
                                                           delegate:nil
                                                  cancelButtonTitle:@"Ok"
                                                  otherButtonTitles:nil];
        [alertView show];
    }];
    
    [operation start];
}


@end
