//
//  DetailViewController.m
//  AuthTogether
//
//  Created by Nuseir Yassin on 11/1/14.
//  Copyright (c) 2014 Nuseir Yassin. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.labelAmount.text = [[self.item objectForKey:@"amount"] stringValue];
    NSString *stringFromDate = [self.item objectForKey:@"createdAt"];
    self.labelDate.text = stringFromDate;
    self.labelStatus.text = [self.item objectForKey:@"status"];
    self.labelDescription.text = [self.item objectForKey:@"description"];
    
    self.labelAuthorizers.text =  [NSString stringWithFormat:@"%lu",[[self.item objectForKey:@"authorizers"] count]] ;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
