//
//  HTTPClient.h
//  AuthTogether
//
//  Created by Nuseir Yassin on 11/1/14.
//  Copyright (c) 2014 Nuseir Yassin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HTTPClient : NSObject

+(HTTPClient *)sharedInstance;

-(NSArray *)getTransactionsForID:(NSString *)phoneNumber;;

@end
