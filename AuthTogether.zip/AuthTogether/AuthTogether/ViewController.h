//
//  ViewController.h
//  AuthTogether
//
//  Created by Nuseir Yassin on 11/1/14.
//  Copyright (c) 2014 Nuseir Yassin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, strong) IBOutlet UITextField *phoneNumber;
@property (nonatomic, strong) IBOutlet UIButton *submitNumberButton;


-(IBAction)submitPhoneNumber:(id)sender;

@end

