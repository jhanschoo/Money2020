//
//  ViewController.m
//  AuthTogether
//
//  Created by Nuseir Yassin on 11/1/14.
//  Copyright (c) 2014 Nuseir Yassin. All rights reserved.
//

#import "ViewController.h"
#import "MainViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    if ([self.phoneNumber respondsToSelector:@selector(setAttributedPlaceholder:)]) {
        UIColor *color = [UIColor whiteColor];
        self.phoneNumber.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Enter Phone Number" attributes:@{NSForegroundColorAttributeName: color}];
    } else {
        NSLog(@"Cannot set placeholder text's color, because deployment target is earlier than iOS 6.0");
        // TODO: Add fall-back code to set placeholder color.
    }
    
    
}

- (void)viewDidAppear:(BOOL)animated {

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)submitPhoneNumber:(id)sender
{
    
    if ([self.phoneNumber.text length] > 5)
    {
        NSString *valueToSave = self.phoneNumber.text;
        [[NSUserDefaults standardUserDefaults] setObject:valueToSave forKey:@"phoneNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

@end
