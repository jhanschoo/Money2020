//
//  HTTPClient.m
//  AuthTogether
//
//  Created by Nuseir Yassin on 11/1/14.
//  Copyright (c) 2014 Nuseir Yassin. All rights reserved.
//

#import "HTTPClient.h"
#import "AFNetworking.h"
#import "MainViewController.h"

static NSString * const BaseURLString = @"http://jhans.ch:3000/";


@implementation HTTPClient

+(HTTPClient *)sharedInstance
{
    static HTTPClient *_sharedInstance = nil;
    static dispatch_once_t oncePredicate;
    
    dispatch_once(&oncePredicate, ^{
        _sharedInstance = [[HTTPClient alloc] init];
        
    });
    return _sharedInstance;
}

-(NSArray *)getTransactionsForID:(NSString *)phoneNumber forController:(id)vc {
    
    
    MainViewController *vc2 = (MainViewController *)vc;
    // 1
    phoneNumber = @"4083685136";
    
    
    NSString *completedString = [NSString stringWithFormat:@"api/user/%@/submission", phoneNumber];
    
    NSString *string = [BaseURLString stringByAppendingString:completedString];
    
    NSURL *url = [NSURL URLWithString:string];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    // 2

    __block NSArray *response = [NSArray new];
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    operation.responseSerializer = [AFJSONResponseSerializer serializer];
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        // 3
        response = (NSArray *)responseObject;
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        // 4
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error Retrieving Data"
                                                            message:[error localizedDescription]
                                                           delegate:nil
                                                  cancelButtonTitle:@"Ok"
                                                  otherButtonTitles:nil];
        [alertView show];
    }];
    
    // 5
    
    [operation start];
    
    NSDictionary *transaction = @{@"id": @1, @"status": @"approved"};
    NSArray *phone =[NSArray arrayWithObjects:transaction, nil];
    return phone;
}


@end
