//
//  NewReportViewController.m
//  AuthTogether
//
//  Created by Nuseir Yassin on 11/1/14.
//  Copyright (c) 2014 Nuseir Yassin. All rights reserved.
//

#import "NewReportViewController.h"

@interface NewReportViewController ()

@end

@implementation NewReportViewController


-(void)awakeFromNib {
    
    UIButton *nextButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    nextButton.frame= CGRectMake(10, 30, 25, 25);
    [nextButton setBackgroundImage:[UIImage imageNamed:@"xbutton.png"] forState:UIControlStateNormal];
    [nextButton addTarget:self action:@selector(closeViewController) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:nextButton];
}

- (void)closeViewController
{
    [self removeFromParentViewController];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)submitReport:(id)sender {
    
    NSLog(@"im here");
    [self dismissViewControllerAnimated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
